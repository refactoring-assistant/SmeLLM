## Code Smell: Middle Man
### Description
If a class performs only one action, delegating work to another class, why does it exist at all?

#### Problem MMBE1.java
`FactoryBad` acts a middle man, delegating all work to `FactorySupervisorBad`. It itself does not seem to have much significance.

```
Observed Code Smells:
- Middle Man (lines 42-59)
```

#### Solution MMBE1.java
Used `Remove Middle Man`. Directly accessed delegate methods of `FactorySupervisorGood` from `FactoryWorkerGood`. This eliminates the need for `FactoryBad/FactoryGood` leading it to be dead code which we can remove.

```
Refactoring Applied:
- Middle Man
    - Remove Middle Man (removed FactoryBad/FactoryGood)
```

```
Observed Code Smells After Refactoring:
- None
```