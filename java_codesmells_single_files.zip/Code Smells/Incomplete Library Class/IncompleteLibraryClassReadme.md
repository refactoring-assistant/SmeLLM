## Code Smell: Incomplete Library Class
### Description
Sooner or later, libraries stop meeting user needs. The only solution to the problem—changing the library—is often impossible since the library is read-only.

#### Problem ILCBE1.java
While using the `Date` class, the developer observes that there is no direct functionality for change of day by 1. So everywhere there is an implementation to update the date. This also leads to code duplication.

```
Observed Code Smells:
- Incomplete Library Class (lines 10-12)
- Duplicated Code (lines 14-16)
```

#### Solution ILCGE1.java
Applied `Foreign Method` to create a private method to calculate days + k where k is the number of days ahead or behind. Reduced duplication and helps overcome the Incomplete Library Class issue.

```
Refactoring Applied:
- Incomplete Library Class
    - Foreign Method (changeDay)
```

```
Observed Code Smells After Refactoring:
- None
```