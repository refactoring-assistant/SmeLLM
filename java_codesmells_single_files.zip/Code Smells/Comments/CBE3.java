/**
 * This class represents a user address.
 **/
class UserAddressBad {
  // Variables are final so that they can be initialized only once
  private final String street;
  private final String city;
  private final String state;

  public UserAddressBad(String street, String city, String state) {
      this.street = street;
      this.city = city;
      this.state = state;
  }

  // Code to print the address of the user in a predefined format
  public void printFormattedAddress() {
    System.out.println("The address of this user is " + street + ", " + city + ", " + state);
  }
}
public class CBE3 {
    public static void main(String[] args) {
        UserAddressBad userAddress = new UserAddressBad("1234", "New York City", "NY");
        userAddress.printFormattedAddress();
    }
}
