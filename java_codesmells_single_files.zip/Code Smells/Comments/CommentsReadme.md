## Code Smell: Comments
### Description
A method is filled with explanatory comments.

#### Problem CBE1.java
The comments seem to explain the method's functionality as it is not clear from the name. It also describes an assertion conditon in which this method should work. Also due to the equation looking complicated, the developer has defined how and why the calculations are done for total amount calculation.

```
Observed Code Smells:
- Comments (lines 17-25)
```

#### Solution CGE1.java
Applied `Extract Variable` to break the complicated expression into sub-expressions. Applied `Rename Method` from `solve()` to `calculateOrderAmount()` so that the functionality is clear by the method name. Applied `Introduce Assertion` since the comment regarding assertion will not force the system to check for this conditon.
```
Refactoring Applied:
- Comments
    - Extract Variable (lines 22-24)
    - Rename Method (solve -> calculateOrderAmount)
    - Introduce Assertion (line 18)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem CBE2.java
The comment explains that the section of code makes a transpose matrix.

```
Observed Code Smells:
- Comments (line 12)
```

#### Solution CGE2.java
Applied `Extract Method` to break the code into a separate method named `transposeMatrix()`. The name itself is indicative that it is for transpose matrix.

```
Refactoring Applied:
- Comments
    - Extract Method (transposeMatrix)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem CBE3.java
The comment is defined to inform the user why the variables are final and what is the significance of the class and method.

```
Observed Code Smells:
- Comments (lines 1-3, 5, 16)
```

#### Solution
Ignore the code smell as the comments are informative and inform the developer why was something done in a certain way.

```
Refactoring Applied:
- None
```

```
Observed Code Smells After Refactoring:
- None (Ignore Comments)
```