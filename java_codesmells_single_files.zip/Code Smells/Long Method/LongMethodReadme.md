## Code Smell: Long Method
### Description
A method contains too many lines of code.

#### Problem LMBE1.java
A single method `makeTransaction` has too many lines of code (30+). Also there are too many switch statements in the method.

```
Observed Code Smells:
- Long Method (line 86-121)
- Switch Statements (line 90-119)
```

#### Solution LMGE1.java
Applied `Extract Method` to break it down into multiple helper methods. Also applied `Decompose Conditional` to wrap complicated parts of the switch logic into their own methods. 

```
Refactoring Applied:
- Long Method
    - Extract Method (performTransaction, checkTransactionValidity, verifyCardDetails, checkAccountStandingAndStatus, checkTransactionAmountWithinLimit)
    - Decompose Conditional (performTransaction, checkTransactionValidity, verifyCardDetails, checkAccountStandingAndStatus, checkTransactionAmountWithinLimit)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem LMBE2.java
The method `calculateAllMotion` is a method with too many lines of code with a lot of temp variables in it.

```
Observed Code Smells:
- Long Method (line 12-25)
```

#### Solution LPGE2.java
Applied `Replace Temp with Query` to replace the temp variables with private method calls. Safe to ignore the data clumps created because making mass and time into a single object would not make a relevant object leading to data class and increase dependency on a new class.

```
Refactoring Applied:
- Long Method
    - Replace Temp with Query (calculateFinalVelocity, calculateFinalDisplacement, calculateTimeToReachGround, calculateMomentum, calculateWeight, calculateKineticEnergy, calculatePower)
```

```
Observed Code Smells After Refactoring:
- None (Ignore Data Clumps)
```