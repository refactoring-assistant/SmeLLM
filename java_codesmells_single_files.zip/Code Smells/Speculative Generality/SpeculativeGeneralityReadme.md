## Code Smell: Duplicate Code
### Description
There’s an unused class, method, field or parameter.

#### Problem SGBE1.java
An abstract class `AccomodationBad` was created with the hope of future use, but it was never used anywhere.
```
Observed Code Smells:
- Speculative Generality (lines 1-4)
```

#### Solution SGGE1.java
Deleted the unused abstract class by `Collapse Hierarchy`.

```
Refactoring Applied:
- Speculative Generality
    - Collapse Hierarchy (Deleted the unused abstract class AccomodationBad)
```

```
Observed Code Smells After Refactoring:
- None
```