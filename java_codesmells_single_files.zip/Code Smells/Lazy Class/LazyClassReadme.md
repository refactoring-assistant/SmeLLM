## Code Smell: Lazy Class
### Description
Understanding and maintaining classes always costs time and money. So if a class doesn’t do enough to earn your attention, it should be deleted.

#### Problem LZCBE1.java
`MatrixOperationValidatorBad` was created assuming future functionality but this class doesn’t do much except validating 2 matrices for operation.

```
Observed Code Smells:
- Lazy Class (lines 4-8)
```

#### Solution LZCGE1.java
Applied `Inline Class` to shift functionality of validator into the operation class.
```
Refactoring Applied:
- Lazy Class
    - Inline Class (lines 48-50)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem LZCBE2.java
The work done by superclass `PrintGreetingsBad` and subclass `PrintHelloUserBad` are similar and can be merged into one class. `PrintHelloUserBad` just delegates the work to its superclass.

```
Observed Code Smells:
- Lazy Class (lines 11-18)
```

#### Solution LZCGE2.java
Applied `Collapse Hierarchy` to merge the superclass and subclass into one class.

```
Refactoring Applied:
- Lazy Class
    - Collapse Hierarchy (PrintGreetingsGood)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem LZCBE3.java
`RGBBad` was created but no one is using it.

```
Observed Code Smells:
- Lazy Class (lines 4-18)
```

#### Solution 
Ignore the code smell of Lazy Class as a developer intends to use this in the future to represent RGB values. The comments are very descriptive on it.

```
Refactoring Applied:
- None
```

```
Observed Code Smells After Refactoring:
- None (Ignore Lazy Class)
```


