class PrintGreetingsGood {
  private String userName;
  public PrintGreetingsGood(String userName) {
    this.userName = userName;
  }
  public void printGreetings() {
    System.out.println("Hello, " + userName + "!");
  }
}
public class LZCGE2 {
    public static void main(String[] args) {
      PrintGreetingsGood helloUser = new PrintGreetingsGood("Alice");
      helloUser.printGreetings();
    }
}
