class PrintGreetingsBad {
    private String userName;
    public PrintGreetingsBad(String userName) {
        this.userName = userName;
    }
    public void printGreetings() {
        System.out.println("Hello, " + userName + "!");
    }
}

class PrintHelloUserBad extends PrintGreetingsBad {
    public PrintHelloUserBad(String userName) {
        super(userName);
    }

    public void printHelloUser() {
        printGreetings();
    }

}
public class LZCBE2 {
    public static void main(String[] args) {
      PrintHelloUserBad helloUser = new PrintHelloUserBad("Alice");
        helloUser.printHelloUser();
    }
}
