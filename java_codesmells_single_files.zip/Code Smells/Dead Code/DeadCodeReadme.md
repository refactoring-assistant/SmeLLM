## Code Smell: Dead Code
### Description
A variable, parameter, field, method or class is no longer used (usually because it’s obsolete).

#### Problem TFBE1.java
Physics engine has dead variable `distance`, dead method `calculateDistance()` and dead parameter `gravity` in the constructor.
```
Observed Code Smells:
- Dead Code (lines 6, 8 and 15)
```

#### Solution TFGE1.java
`Deleted` unused code such as dead variable and dead method. Applied `Remove Parameter` on the unused parameter.

```
Refactoring Applied:
- Dead Code
    - Deleted unused code (distance and calculateDistance())
    - Remove Parameter (gravity)
```

```
Observed Code Smells After Refactoring:
- None
```