class ShapeBad {
  private String shape;
  public ShapeBad(String shape) {
    this.shape = shape;
  }

  public double calculateArea(int ... dimensions) {
    switch(shape) {
      case "circle":
        return Math.PI * dimensions[0] * dimensions[0];
      case "rectangle":
        return dimensions[0] * dimensions[1];
      case "triangle":
        return 0.5 * dimensions[0] * dimensions[1];
      case "square":
        return dimensions[0] * dimensions[0];
      default:
        return 0;
    }
  }
}

public class SWSBE1 {
    public static void main(String[] args) {
        ShapeBad circle = new ShapeBad("circle");
        System.out.println("Area of circle: " + circle.calculateArea(5));
        ShapeBad rectangle = new ShapeBad("rectangle");
        System.out.println("Area of rectangle: " + rectangle.calculateArea(5, 10));
        ShapeBad triangle = new ShapeBad("triangle");
        System.out.println("Area of triangle: " + triangle.calculateArea(5, 10));
        ShapeBad square = new ShapeBad("square");
        System.out.println("Area of square: " + square.calculateArea(5));
    }
}
