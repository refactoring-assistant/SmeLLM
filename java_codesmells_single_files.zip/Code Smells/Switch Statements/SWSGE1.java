abstract class ShapeGood {
    abstract double calculateArea();
}

class CircleGood extends ShapeGood {
    private double radius;

    public CircleGood(double radius) {
        this.radius = radius;
    }

    @Override
    double calculateArea() {
        return Math.PI * radius * radius;
    }
}

class RectangleGood extends ShapeGood {
    private double length;
    private double breadth;

    public RectangleGood(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
    }

    @Override
    double calculateArea() {
        return length * breadth;
    }
}

class TriangleGood extends ShapeGood {
    private double base;
    private double height;

    public TriangleGood(double base, double height) {
        this.base = base;
        this.height = height;
    }

    @Override
    double calculateArea() {
        return 0.5 * base * height;
    }
}

class SquareGood extends ShapeGood {
    private double side;

    public SquareGood(double side) {
        this.side = side;
    }

    @Override
    double calculateArea() {
        return side * side;
    }
}
public class SWSGE1 {
    public static void main(String[] args) {
        ShapeGood circle = new CircleGood(5);
        System.out.println("Area of circle: " + circle.calculateArea());
        ShapeGood rectangle = new RectangleGood(5, 10);
        System.out.println("Area of rectangle: " + rectangle.calculateArea());
        ShapeGood triangle = new TriangleGood(5, 10);
        System.out.println("Area of triangle: " + triangle.calculateArea());
        ShapeGood square = new SquareGood(5);
        System.out.println("Area of square: " + square.calculateArea());
    }
}
