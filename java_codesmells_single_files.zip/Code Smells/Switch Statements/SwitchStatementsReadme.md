## Code Smell: Switch Statements
### Description
You have a complex `switch` operator or sequence of `if` statements.


#### Problem SWSBE1.java
In `ShapeBad`, `calculateArea()` depends on the type of shape to decide which calculation to perform and how to access dimensions.
```
Observed Code Smells:
- Switch Statements (lines 8-19)
```

#### Solution SWSGE1.java
Applied `Replace Conditional with Polymorphism` to create individual classes implementing the `calculateArea()` method.

```
Refactoring Applied:
- Switch Statements
    - Replace Conditional with Polymorphism (CircleGood, RectangleGood, SquareGood, TriangleGood)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem SWSBE2.java
The clas `UserRouteBad` has a switch statement to decide the route based on the type code `routeType`.
```
Observed Code Smells:
- Switch Statements (lines 13-25)
```

#### Solution SWSGE2.java
Applied `Replace Type Code with Strategy` to replace the type code with different strategies to calculate effects of choosing different routes.

```
Refactoring Applied:
- Switch Statements
    - Replace Type Code with Strategy (CarRouteStrategy, BikeRouteStrategy, WalkRouteStrategy, BusRouteStrategy)
```

```
Observed Code Smells After Refactoring:
- None
```