## Code Smell: Divergent Change
### Description
Divergent Change is when many changes are made to a single class.

#### Problem DVCHBE1.java
The printing for each operation seems to do similar things. So if any changes are made to the printing, it would have to be made in multiple places.

```
Observed Code Smells:
- Divergent Change (lines 17, 26, 45)
```

#### Solution DVCHGE1.java
Applied `Extract Class` to extract out logging code to a separate logger class.

```
Refactoring Applied:
- Divergent Change
    - Extract Class (PrintLoggerGood)
```

```
Observed Code Smells After Refactoring:
- None
```