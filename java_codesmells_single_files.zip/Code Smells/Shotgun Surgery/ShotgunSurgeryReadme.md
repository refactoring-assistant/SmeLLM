## Code Smell: Shotgun Surgery
### Description
Shotgun Surgery refers to when a single change is made to multiple classes simultaneously.

#### Problem SSBE1.java
Both `MathClassBad` and `EnglishClassBad` have private methods which seem to access the method of `SubjectsGradingBad` a lot and have similar methods. Changing grading scheme in one class might need to change the grading scheme in another.
```
Observed Code Smells:
- Shotgun Surgery (lines 42-54 and 72-84)
- Feature Envy (lines 42-54 and 72-84)
```

#### Solution SSGE1.java
Applied `Move Method` to move the common logic to SubjectGradeGood. This reduces duplication and ensures that the logic for grading remains in the class it is meant to be in.
```
Refactoring Applied:
- Shotgun Surgery
    - Move Method (setGradeBasedOnMarks)
```

```
Observed Code Smells After Refactoring:
- None
```