class RectangleGood {
  private final double height;
  private final double width;
  public RectangleGood(double height, double width) {
    this.height = height;
    this.width = width;
  }
  public double getPerimeter() {
    return 2 * (height + width);
  }
  public double getArea() {
      return height * width;
  }
}
public class DCLSGE1 {
  public static void main(String[] args) {
    RectangleGood rectangle = new RectangleGood(5, 10);
    double perimeter = rectangle.getPerimeter();
    System.out.println("Perimeter of rectangle: " + perimeter);
    double area = rectangle.getArea();
    System.out.println("Area of rectangle: " + area);
  }
}
