## Code Smell: Data Class
### Description
A data class refers to a class that contains only fields and crude methods for accessing them (getters and setters). These are simply containers for data used by other classes. These classes don’t contain any additional functionality and can’t independently operate on the data that they own.
#### Problem DCLSBE1.java
`RectangleBad` only has setters and getters while the computation is done on the outside.
```
Observed Code Smells:
- Data Class (lines 1-17)
```

#### Solution DCLSGE1.java
Applied `Remove Setting Method`, and `Hide Method` for getters. Applied `Move Method` on the calculation of perimeter and area.
```
Refactoring Applied:
- Data Class
    - Remove Setting Method and Hide Method (Removed the getters for data)
    - Move Method (getPerimeter, getArea)
```

```
Observed Code Smells After Refactoring:
- None
```