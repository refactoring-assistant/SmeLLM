## Code Smell: Feature Envy
### Description
A method accesses the data of another object more than its own data.

#### Problem FEBE1.java
The data of `Coordinates2DBad` are accessed continuously. Also, the class does not have any other functionality except getters.
```
Observed Code Smells:
- Feature Envy (lines 40-41 and 47)
- Data Class (lines 1-12)
```

#### Solution LCGE1.java
Used `Move Method` to move calculation of distance to the coordinate class. `Extract Method` to extract out the data access and moved it to `Coordinates2DGood` class.

```
Refactoring Applied:
- Feature Envy
    - Move Method (calculateDistance)
    - Extract Method with Move method (sameX, sameY)
```

```
Observed Code Smells After Refactoring:
- None
```