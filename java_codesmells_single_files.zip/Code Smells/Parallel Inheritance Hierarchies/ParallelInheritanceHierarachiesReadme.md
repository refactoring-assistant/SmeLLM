## Code Smell: Parallel Inheritance Hierarchies
### Description
Whenever you create a subclass for a class, you find yourself needing to create a subclass for another class.

#### Problem PIHBE1.java
Implementing `CarBad` leads to implementing `CarFactoryBad` and implementing `BikeBad` leads to implementing `BikeFactoryBad`. Similarly, for other vehicle types we will have to keep on adding an extra class for every type created.

```
Observed Code Smells:
- Parallel Inheritance Hierarchies (lines 42-104)
```

#### Solution PIHGE1.java
Used `Move Method` and `Move Field` to move `Factory` functionalities into `Vehicle`. This also helped remove the factory hierarchy completely.

```
Refactoring Applied:
- Parallel Inheritance Hierarchies
    - Move Method and Move Field (All factory methods moved to Vehicle)
```

```
Observed Code Smells After Refactoring:
- None
```