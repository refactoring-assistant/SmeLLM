interface VehicleGood {
  void createVehicle();
  void testFunctionality();
  void printVehicleInfo();
}

abstract class AbstractVehicle implements VehicleGood {
    private String model;
    private String engineType;
    protected String factoryName;

    public AbstractVehicle(String model, String engineType, String factory) {
        this.model = model;
        this.engineType = engineType;
        this.factoryName = factory;
    }

    public void printVehicleInfo() {
        System.out.println("Model: " + model
                + ", Engine Type: " + engineType);
    }
}


class CarGood extends AbstractVehicle {


  public CarGood(String model, String engineType, String factory) {
    super(model, engineType, factory);

  }
  @Override
  public void createVehicle() {
    System.out.println("Car created at " + factoryName);
  }

  @Override
  public void testFunctionality() {
    System.out.println("Car tested at " + factoryName);
  }

}


class BikeGood extends AbstractVehicle {
  public BikeGood(String model, String engineType, String factory) {
    super(model, engineType, factory);
  }

  @Override
  public void createVehicle() {
    System.out.println("Bike created at " + factoryName);
  }

  @Override
  public void testFunctionality() {
    System.out.println("Bike tested at " + factoryName);
  }
}

public class PIHGE1 {
  public static void main(String[] args) {
    VehicleGood car = new CarGood("SUV", "Petrol", "Default SUV Factory");
    car.createVehicle();
    car.testFunctionality();
    car.printVehicleInfo();
    VehicleGood car2 = new CarGood("SUV", "Petrol", "New Car Factory");
    car2.createVehicle();
    car2.testFunctionality();
    car2.printVehicleInfo();

    System.out.println();

    VehicleGood bike = new BikeGood("Mountain Bike", "Electric", "Default Mountain Bike Factory");
    bike.createVehicle();
    bike.testFunctionality();
    bike.printVehicleInfo();
    VehicleGood bike2 = new BikeGood("Mountain Bike", "Electric", "New Bike Factory");
    bike2.createVehicle();
    bike2.testFunctionality();
    bike2.printVehicleInfo();
  }
}
