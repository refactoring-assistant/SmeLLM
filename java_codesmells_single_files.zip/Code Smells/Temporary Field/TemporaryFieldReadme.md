## Code Smell: Temporary Field
### Description
Temporary fields get their values (and thus are needed by objects) only under certain circumstances. Outside of these circumstances, they’re empty.


#### Problem TFBE1.java
`monthlyInterestRate` and `numMonths` are fields only used if term is less than 1 year. Or else there is no use for them.

```
Observed Code Smells:
- Temporary Field (lines 20-21)
- Primitive Obsession (lines 2-7)
```

#### Solution TFGE1.java
Applied `Extract Class` to extract into a `MonthlyInterestCalculatorGood` and performed action similar to `Replace Method with Method Object`.

```
Refactoring Applied:
- Temporary Field
    - Extract Class (MonthlyInterestCalculatorGood)
```

```
Observed Code Smells After Refactoring:
- None
```