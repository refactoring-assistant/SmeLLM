## Code Smell: Duplicate Code
### Description
Two code fragments look almost identical.
#### Problem DUPCBE1.java
The print statements are duplicated across all methods.
```
Observed Code Smells:
- Duplicate Code (lines 14-16, 21-23, 29-31)
```

#### Solution DUPCGE1.java
Applied `Extract Method` as it’s a duplication in the same class.

```
Refactoring Applied:
- Duplicate Code
    - Extract Method (printAccountDetails)
```

```
Observed Code Smells After Refactoring:
- None
```