class BankAccountGood {
  private double balance;
  private String owner;
  private String accountNumber;

  public BankAccountGood(double balance, String owner, String accountNumber) {
    this.balance = balance;
    this.owner = owner;
    this.accountNumber = accountNumber;
  }

  public void deposit(double amount) {
    balance += amount;
    printAccountDetails();
  }

  public void withdraw(double amount) {
    balance -= amount;
    printAccountDetails();
  }

  public void transfer(double amount, BankAccountGood otherAccount) {
    balance -= amount;
    otherAccount.balance += amount;
    printAccountDetails();
  }

  private void printAccountDetails() {
    System.out.println("Owner: " + owner);
    System.out.println("Account number: " + accountNumber);
    System.out.println("Balance: " + balance);
  }
}

public class DUPCGE1 {
  public static void main(String[] args) {
    BankAccountGood account1 = new BankAccountGood(1000, "John", "123456789");
    BankAccountGood account2 = new BankAccountGood(2000, "Jane", "987654321");

    account1.deposit(500);
    account1.withdraw(200);
    account1.transfer(100, account2);
  }
}
