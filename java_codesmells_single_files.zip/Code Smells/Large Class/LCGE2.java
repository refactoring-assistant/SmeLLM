interface IPersonGood {
   void printPersonDetails();
}

interface IStudentGood extends IPersonGood {
  void printStudentDetails();
}

class PersonGood implements IPersonGood {
  private String name;

  public PersonGood(String name) {
    this.name = name;
  }

  public void printPersonDetails() {
    System.out.println("Name: " + this.name);
  }
}

class StudentGood extends PersonGood implements IStudentGood {
  private String studentId;
  private String major;

  public StudentGood(String name, String studentId, String major) {
    super(name);
    this.studentId = studentId;
    this.major = major;
  }

  public void printStudentDetails() {
    printPersonDetails();
    System.out.println("Student ID: " + this.studentId);
    System.out.println("Major: " + this.major);
  }
}

public class LCGE2 {
  public static void main(String[] args) {
    IStudentGood person1 = new StudentGood("John", "123456", "Computer Science");
    System.out.println("Only person details:");
    person1.printPersonDetails();
    System.out.println("Student details:");
    person1.printStudentDetails();
  }
}
