interface IPersonBad {
  void printPersonDetails();
  void printStudentDetails();
}
class PersonBad implements IPersonBad {
  private String name;
  private String studentId;
  private String major;

  public PersonBad(String name, String studentId, String major) {
    this.name = name;
    this.studentId = studentId;
    this.major = major;
  }

  public void printPersonDetails() {
    System.out.println("Name: " + this.name);
  }

  public void printStudentDetails() {
    printPersonDetails();
    System.out.println("Student ID: " + this.studentId);
    System.out.println("Major: " + this.major);
  }
}

public class LCBE2 {
    public static void main(String[] args) {
        IPersonBad person1 = new PersonBad("John", "123456", "Computer Science");
        System.out.println("Only person details:");
        person1.printPersonDetails();
        System.out.println("Student details:");
        person1.printStudentDetails();
    }
}
