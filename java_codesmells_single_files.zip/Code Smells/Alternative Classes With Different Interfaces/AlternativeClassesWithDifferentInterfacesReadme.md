## Code Smell: Alternative Classes With Different Interfaces
### Description
Two classes perform identical functions but have different method names.

#### Problem ACDIBE1.java
`LionBad` and `RabbitBad` do similar stuff although they have different method names.
```
Observed Code Smells:
- Alternative Classes With Different Interfaces (lines 1-15 and 17-31)
```

#### Solution ACDIGE1.java
Made a common interface. Applied `Rename Methods`. Did `Extract Superclass` to move the common functionality to the abstract class and made the remaining classes as subclasses.
```
Refactoring Applied:
- Alternative Classes With Different Interfaces
    - Rename Method (animalVoice and animalInfo)
    - Extract Superclass (AbstractAnimal)
```

```
Observed Code Smells After Refactoring:
- None
```