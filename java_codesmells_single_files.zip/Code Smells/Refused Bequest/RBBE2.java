interface NoteTakerBad {
    void writeNotes();
    void shareNotesAsPdf();
}

class IpadNotesBad implements NoteTakerBad {
    @Override
    public void writeNotes() {
        System.out.println("Notes written on iPad.");
    }

    @Override
    public void shareNotesAsPdf() {
        System.out.println("Notes shared as PDF.");
    }
}

class NotebookNotesBad implements NoteTakerBad {
    @Override
    public void writeNotes() {
        System.out.println("Notes written on Notebook.");
    }

    @Override
    public void shareNotesAsPdf() {
        throw new UnsupportedOperationException("Notebook does not support sharing notes as PDF.");
    }
}
public class RBBE2 {
    public static void main(String[] args) {
      try {
        NoteTakerBad ipad = new IpadNotesBad();
        ipad.writeNotes();
        ipad.shareNotesAsPdf();

        NoteTakerBad notebook = new NotebookNotesBad();
        notebook.writeNotes();
        notebook.shareNotesAsPdf();
      }
      catch (UnsupportedOperationException e) {
        System.out.println(e.getMessage());
      }

    }
}
