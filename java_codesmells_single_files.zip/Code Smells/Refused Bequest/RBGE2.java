interface NoteTakerGood {
  void writeNotes();
}

class IpadNotesGood implements NoteTakerGood {
  @Override
  public void writeNotes() {
    System.out.println("Notes written on iPad.");
  }

  public void shareNotesAsPdf() {
    System.out.println("Notes shared as PDF.");
  }
}

class NotebookNotesGood implements NoteTakerGood {
  @Override
  public void writeNotes() {
    System.out.println("Notes written on Notebook.");
  }

}
public class RBGE2 {
  public static void main(String[] args) {
    NoteTakerGood ipad = new IpadNotesGood();
    ipad.writeNotes();
   ((IpadNotesGood) ipad).shareNotesAsPdf();

    NoteTakerGood notebook = new NotebookNotesGood();
    notebook.writeNotes();
  }
}
