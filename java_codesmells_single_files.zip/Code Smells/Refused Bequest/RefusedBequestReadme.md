## Code Smell: Refused Bequest
### Description
If a subclass uses only some of the methods and properties inherited from its parents, the hierarchy is off-kilter. The unneeded methods may simply go unused or be redefined and give off exceptions.



#### Problem RBBE1.java
`MobileBad` inherits `switchOnOff()` and `printDetails()` from `ComputerBad`, but it also ends up inheriting `clickedKeyboard()` and `moveMouse()` which it does not need.

```
Observed Code Smells:
- Refused Bequest (lines 62 and 66)
```

#### Solution RBGE1.java
Applied `Replace Inheritance with Delegation` to help `MobileGood` only maintain methods it needs.


```
Refactoring Applied:
- Refused Bequest
    - Replace Inheritance with Delegation (computer field in MobileGood)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem RBBE2.java
The interface `NoteTakerBad` enforces sharing notes as pdf which cannot be supported by `NotebookNotesBad`.

```
Observed Code Smells:
- Refused Bequest (line 25-27)
```

#### Solution RBGE2.java
Applied `Extract Superclass` to extract out the common methods to `NoteTakerGood` and got rid of unneeded methods from `NotebookNotesBad`.

```
Refactoring Applied:
- Refused Bequest
    - Extract Superclass (NoteTakerGood)
```

```
Observed Code Smells After Refactoring:
- None
```