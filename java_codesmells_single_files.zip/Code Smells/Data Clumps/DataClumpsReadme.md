## Code Smell: Data Clumps
### Description
Sometimes different parts of the code contain identical groups of variables (such as parameters for connecting to a database).

#### Problem DCBE1.java
The methods in `FlightBookingBad` seem to have the parameters `customerFirstName`, `customerLastName`, `PNR` repeated a lot. Also the class seems to have a lot of primitive values. The number of parameters in some cases exceed 4 parameters.

```
Observed Code Smells:
- Data Clumps (lines 15, 28, 38, 46) 
- Primitive Obsession (lines 4-11)
- Long Parameter List (lines 15, 28, 38, 46) 
```

#### Solution DCGE1.java
Applied `Extract Class` on customer related details and travel related details. Also implemented `Introduce Parameter Objects` to replace multiple parameters with a single object. 

```
Refactoring Applied:
- Data Clumps
    - Extract Class (ContactGood, CustomerGood, BookingReferenceGood, TravelPlaceGood)
    - Introduce Parameter Objects (BookingReferenceGood, ContactGood, TravelPlaceGood in method parameters.)
- Primitive Obsession
    - Introduce Parameter Objects (BookingReferenceGood, ContactGood, TravelPlaceGood in method parameters.)
- Long Parameter List
    - Introduce Parameter Objects (BookingReferenceGood, ContactGood, TravelPlaceGood in method parameters.)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem DCBE2.java
The methods in `CompareWeatherPatternsBad`, `isWeather1Greater` and `averageAcross2Weathers` seems to clump `weather1List` and `weather1List`. 

```
Observed Code Smells:
- Data Clumps (lines 41 and 53) 
```

#### Solution DCGE2.java
Applied `Preserve Whole Object` to pass the entire object instead of passing individual parameters.

```
Refactoring Applied:
- Data Clumps
    - Preserve Whole Object (TwinCityWeatherSeriesGood object as parameters).
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem DCBE3.java
The methods in `InterestCalculatorBad`, `calculateSimpleInterest` and `calculateCompoundInterest` seem to clump `principal`, `rate`, `time` together. 

```
Observed Code Smells:
- Data Clumps (lines 71 and 75) 
```

#### Solution
`Ignore` the data clumps in this case as passing in the parameters can be considered better than passing in the `ILoanValuesBad`. Passing the object increases
the coupling between the classes creating an undesirable dependency.

```
Refactoring Applied:
- None
```

```
Observed Code Smells After Refactoring:
- None (Ignore Data Clumps)
```