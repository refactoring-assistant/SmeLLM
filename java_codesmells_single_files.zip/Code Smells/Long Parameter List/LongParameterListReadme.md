## Code Smell: Long Parameter List
### Description
More than three or four parameters for a method.

#### Problem LPLBE1.java
The constructor of PersonBad has 9 parameters as input.

```
Observed Code Smells:
- Long Parameter List (line 41)
```

#### Solution LPLGE1.java
We applied `Preserve Whole Object` to make the parameters into a single object. 

```
Refactoring Applied:
- Long Parameter List
    - Preserve Whole Object (AddressGood address, BankAccountGood bankAccount)
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem LPLBE2.java
`calculateCartPrice()` method has 5 parameters. This is due to the method taking in different values from multiple different objects during its call.

```
Observed Code Smells:
- Long Parameter List (line 70)
```

#### Solution LPLGE2.java
Applied `Replace Parameter with Method Call`. The class `ShoppingCartGood` now takes in information on the store's pricing policy and the member's pricing policy. `calculateCartPrice()` now queries these objects directly internally for the required values.


```
Refactoring Applied:
- Long Parameter List
    - Replace Parameter with Method Call (shifted queries for values inside the method calculateCartPrice())
```

```
Observed Code Smells After Refactoring:
- None
```

#### Problem LPLBE3.java
`TriangleBad` takes in 6 parameters to assign as coordinates to the points of the triangle.

```
Observed Code Smells:
- Long Parameter List (line 18)
```

#### Solution LPLGE3.java
Applied `Introduce Parameter Object` to replace the parameters with parameter objects of `Coordinates2DGood`. This reduces the number of parameters in the constructor.

```
Refactoring Applied:
- Long Parameter List
    - Introduce Parameter Object (replaced parameters of constructor of TriangleGood with objects of Coordinates2DGood)
```

```
Observed Code Smells After Refactoring:
- None
```