## Code Smell: Inappropriate Intimacy
### Description
One class uses the internal fields and methods of another class.

#### Problem IIBE1.java
`SubjectMarksBad` fields are not private. This leads its delegate `EnglishBad` to access its internal fields and modify them as the delegate wants. 
Also, although `EnglishBad` extends `SubjectMarksBad`, it calls on its `getGrade()` using a delegator. 
Also, `TeacherBad` is able to access the internal marks field and edit it even though it is not defined to be an intended behaviour by the developer.

```
Observed Code Smells:
- Inappropriate Intimacy (lines 38, 43, 58)
```

#### Solution IIGE1.java
Applied `Replace Delegation with Inheritance` to reduce duplication between `EnglishGood` and `SubjectMarksGood`. Applied `Encapsulate Field` . This is not exactly a treatment prescribed in Refactoring Guru but step 1 of `Move Field`.

```
Refactoring Applied:
- Inappropriate Intimacy
    - Replace Delegation with Inheritance (Removed delegator from subclass)
    - Move Field (made the fields private by encapsulating them)
```

```
Observed Code Smells After Refactoring:
- None
```