## Code Smell: Message Chains
### Description
In code you see a series of calls resembling $a->b()->c()->d()

#### Problem MCBE1.java
`OrderHistoryBad` tries to access person name and address by forming chains calling objects sequentially. Also, `PersonBad` and `AddressBad` have a functionality of only representing data than doing anything else.


```
Observed Code Smells:
- Message Chains (lines 91-92)
```

#### Solution MCGE1.java
Applied `Hide Delegate` to hide the calls to `AddressGood` and `PersonGood`. Also applied `Extract Method` and `Move Method` to handle printing of person and address in `OrderGood` instead of `OrderHistoryGood`.

```
Refactoring Applied:
- Message Chains
    - Hide Delegate (getAddress, getPerson)
    - Extract Method and Move Method (printOrderDetails)
```

```
Observed Code Smells After Refactoring:
- None
```